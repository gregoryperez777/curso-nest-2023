# TypeScript introducción para Nest
Este proyecto es el respaldo de lo que hicimos en la introducción de mi curso de Nest en la parte de introducción a TypeScript.

## No olvidar ejecutar
```
yarn install
yarn dev
```

Para instalar y ejecutar el proyecto.
